"use strict";
exports.id = 806;
exports.ids = [806];
exports.modules = {

/***/ 2806:
/***/ ((module) => {

module.exports = JSON.parse('{"Xd":{"aD":"Buying Concepts","Tb":"https://formspree.io/f/your_api_key"},"Fs":{"jY":{"BH":"/images/logo_new0.png","gB":"/images/logo_new0.png","wp":"logo"},"GI":[{"label":"Home","link":"/","children":0},{"label":"About Us","link":"/about","children":0},{"label":"Products","link":"/projects","children":0},{"label":"Contact Us","link":"/contact","children":0}],"LI":{"P":"Products","p":"/projects"},"NK":{"P":"Start a Project","p":"/contact"}},"Mv":{"jY":{"B":"/images/logo_new0.png","w":"logo"},"lj":[{"image":"/images/footer/1.jpg","title":"image","alt":"image"},{"image":"/images/footer/2.jpg","title":"image","alt":"image"},{"image":"/images/footer/3.jpg","title":"image","alt":"image"},{"image":"/images/footer/4.jpg","title":"image","alt":"image"},{"image":"/images/footer/5.jpg","title":"image","alt":"image"},{"image":"/images/footer/6.jpg","title":"image","alt":"image"}],"JG":"© 2025 Buying Concepts. All rights reserved."},"xs":[{"link":"https://facebook.com","icon":"fab fa-facebook","title":"Facebook"},{"link":"https://twitter.com","icon":"fab fa-twitter","title":"Twitter"},{"link":"https://linkedin.com","icon":"fab fa-linkedin","title":"Linkedin"}]}');

/***/ })

};
;