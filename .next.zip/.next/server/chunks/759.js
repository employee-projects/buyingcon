"use strict";
exports.id = 759;
exports.ids = [759];
exports.modules = {

/***/ 4759:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Partners)
});

// EXTERNAL MODULE: ./node_modules/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(5893);
;// CONCATENATED MODULE: ./src/data/sections/partners.json
const partners_namespaceObject = JSON.parse('{"TN":"Our Clients","ev":[{"label":"Visit Website","image":"/images/clients/belk.jpg"},{"label":"Visit Website","image":"/images/clients/kidpik.jpg"},{"label":"Visit Website","image":"/images/clients/albert.jpg"},{"label":"Visit Website","image":"/images/clients/denim.jpg"},{"label":"Visit Website","image":"/images/clients/kahn.jpg"},{"label":"Visit Website","image":"/images/clients/cherokee2.jpg"},{"label":"Visit Website","image":"/images/clients/AHOLD2.jpg"},{"label":"Visit Website","image":"/images/clients/shilmel_zagvar.jpg"}]}');
;// CONCATENATED MODULE: ./src/components/sections/Partners.jsx


const PartnersSection = ({ paddingTop  })=>{
    return /*#__PURE__*/ jsx_runtime.jsx(jsx_runtime.Fragment, {
        children: /*#__PURE__*/ jsx_runtime.jsx("section", {
            className: paddingTop ? "onovo-section gap-top-40" : "onovo-section",
            children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "container",
                children: [
                    /*#__PURE__*/ jsx_runtime.jsx("div", {
                        className: "onovo-heading gap-top-140 gap-bottom-40",
                        children: /*#__PURE__*/ jsx_runtime.jsx("h2", {
                            className: "onovo-title-2",
                            children: /*#__PURE__*/ jsx_runtime.jsx("span", {
                                dangerouslySetInnerHTML: {
                                    __html: partners_namespaceObject.TN
                                }
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("div", {
                        className: "row gap-row",
                        children: partners_namespaceObject.ev.map((item, key)=>/*#__PURE__*/ jsx_runtime.jsx("div", {
                                className: "col-6 col-xs-6 col-sm-6 col-md-4 col-lg-3",
                                children: /*#__PURE__*/ jsx_runtime.jsx("div", {
                                    className: "onovo-brands ",
                                    "data-onovo-overlay": true,
                                    "data-onovo-scroll": true,
                                    children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                        target: "_blank",
                                        href: item.link,
                                        children: /*#__PURE__*/ jsx_runtime.jsx("span", {
                                            className: "",
                                            children: /*#__PURE__*/ jsx_runtime.jsx("img", {
                                                decoding: "async",
                                                src: item.image,
                                                width: "75%",
                                                loading: "lazy",
                                                alt: item.alt
                                            })
                                        })
                                    })
                                })
                            }, `partners-item-${key}`))
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const Partners = (PartnersSection);


/***/ })

};
;